package com.example.switchcontrol.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.switchcontrol.ui.theme.*

// Modelo de timer para la UI
data class TimerUiModel(
    val index: Int,
    val isActive: Boolean,
    val startHour: Int = 0,
    val startMin: Int = 0,
    val endHour: Int = 0,
    val endMin: Int = 1,
    val days: Set<Int> = emptySet() // 0=Do, 1=Lu, 2=Ma, 3=Mi, 4=Ju, 5=Vi, 6=Sa
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeviceDetailScreen(
    deviceName: String,
    accentColor: Color,
    position: Int,        // posición en la lista (para reordenar)
    timers: List<TimerUiModel>,
    onBack: () -> Unit,
    onSave: () -> Unit,
    onDiscard: () -> Unit,
    onNameChange: () -> Unit,
    onColorChange: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onTimerClick: (Int) -> Unit,
    onModeClick: () -> Unit,
    onMaintenanceClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Scaffold(
        containerColor = BackgroundDark,
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Volver",
                            tint = OnSurfacePrimary
                        )
                    }
                },
                title = {
                    Text(
                        text = deviceName,
                        style = MaterialTheme.typography.titleLarge,
                        color = OnSurfacePrimary,
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = BackgroundDark
                )
            )
        },
        bottomBar = {
            // Botones Aceptar / Descartar
            Surface(
                color = SurfaceCard,
                tonalElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDiscard,
                        modifier = Modifier.weight(1f),
                        border = BorderStroke(1.dp, SurfaceBorder),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = OnSurfaceMuted
                        )
                    ) {
                        Icon(Icons.Rounded.Close, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Descartar")
                    }
                    Button(
                        onClick = onSave,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = accentColor,
                            contentColor = Color.Black.copy(0.85f)
                        )
                    ) {
                        Icon(Icons.Rounded.Check, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Aceptar", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // ── Sección: Nombre ──────────────────────────────────
            DetailSection(label = "INTERRUPTOR WIFI") {
                DetailRow(
                    icon = Icons.Rounded.Edit,
                    label = "nombre",
                    value = deviceName,
                    accentColor = accentColor,
                    onClick = onNameChange
                )
            }

            // ── Sección: Vista ───────────────────────────────────
            DetailSection(label = "VISTA") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(SurfaceElevated)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Posición
                    Text(
                        text = "#$position",
                        style = MaterialTheme.typography.titleMedium,
                        color = accentColor,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.width(4.dp))

                    // Botones mover
                    FilledTonalIconButton(
                        onClick = onMoveUp,
                        modifier = Modifier.size(36.dp),
                        colors = IconButtonDefaults.filledTonalIconButtonColors(
                            containerColor = SurfaceCard
                        )
                    ) {
                        Icon(Icons.Rounded.KeyboardArrowUp, null, Modifier.size(18.dp), tint = OnSurfaceMuted)
                    }
                    FilledTonalIconButton(
                        onClick = onMoveDown,
                        modifier = Modifier.size(36.dp),
                        colors = IconButtonDefaults.filledTonalIconButtonColors(
                            containerColor = SurfaceCard
                        )
                    ) {
                        Icon(Icons.Rounded.KeyboardArrowDown, null, Modifier.size(18.dp), tint = OnSurfaceMuted)
                    }

                    Spacer(Modifier.weight(1f))

                    // Color picker
                    IconButton(onClick = onColorChange) {
                        Icon(Icons.Rounded.Palette, null, tint = OnSurfaceMuted)
                    }
                    // Muestra el color actual
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(accentColor)
                            .clickable(onClick = onColorChange)
                    )
                }
            }

            // ── Sección: Timers ──────────────────────────────────
            DetailSection(label = "TIMERS") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(SurfaceElevated),
                ) {
                    timers.forEachIndexed { index, timer ->
                        TimerRow(
                            timer = timer,
                            accentColor = accentColor,
                            onClick = { onTimerClick(index) }
                        )
                        if (index < timers.size - 1) {
                            HorizontalDivider(
                                modifier = Modifier.padding(horizontal = 16.dp),
                                color = SurfaceBorder.copy(alpha = 0.5f)
                            )
                        }
                    }
                }
            }

            // ── Sección: Config adicional ────────────────────────
            DetailSection(label = "CONFIGURACIÓN ADICIONAL") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ConfigButton(
                        icon  = Icons.Rounded.Tune,
                        label = "Modo",
                        color = accentColor,
                        onClick = onModeClick,
                        modifier = Modifier.weight(1f)
                    )
                    ConfigButton(
                        icon  = Icons.Rounded.Build,
                        label = "Mantenimiento",
                        color = OnSurfaceMuted,
                        onClick = onMaintenanceClick,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(Modifier.height(8.dp))
        }
    }
}

// ─── Componentes internos ─────────────────────────────────────────

@Composable
private fun DetailSection(
    label: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = OnSurfaceMuted,
            letterSpacing = androidx.compose.ui.unit.TextUnit(1.5f, androidx.compose.ui.unit.TextUnitType.Sp)
        )
        content()
    }
}

@Composable
private fun DetailRow(
    icon: ImageVector,
    label: String,
    value: String,
    accentColor: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        color = SurfaceElevated
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(icon, null, tint = OnSurfaceMuted, modifier = Modifier.size(18.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = OnSurfaceMuted
            )
            Spacer(Modifier.weight(1f))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                color = accentColor,
                fontWeight = FontWeight.SemiBold
            )
            Icon(
                Icons.Rounded.ChevronRight, null,
                tint = OnSurfaceMuted.copy(0.5f),
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
private fun TimerRow(
    timer: TimerUiModel,
    accentColor: Color,
    onClick: () -> Unit
) {
    val daysLabel = listOf("do", "lu", "ma", "mi", "ju", "vi", "sa")

    Surface(
        onClick = onClick,
        color = Color.Transparent
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                Icons.Rounded.Schedule,
                null,
                tint = if (timer.isActive) accentColor else OnSurfaceMuted.copy(0.4f),
                modifier = Modifier.size(18.dp)
            )

            if (timer.isActive) {
                Column {
                    Text(
                        text = "%02d:%02d → %02d:%02d".format(
                            timer.startHour, timer.startMin,
                            timer.endHour, timer.endMin
                        ),
                        style = MaterialTheme.typography.bodyMedium,
                        color = OnSurfacePrimary
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        daysLabel.forEachIndexed { idx, day ->
                            Text(
                                text = day,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (idx in timer.days) accentColor else OnSurfaceMuted.copy(0.3f)
                            )
                        }
                    }
                }
            } else {
                Text(
                    text = "inactivo",
                    style = MaterialTheme.typography.bodyMedium,
                    color = OnSurfaceMuted.copy(0.4f)
                )
            }

            Spacer(Modifier.weight(1f))
            Icon(
                Icons.Rounded.ChevronRight, null,
                tint = OnSurfaceMuted.copy(0.3f),
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
private fun ConfigButton(
    icon: ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = SurfaceElevated
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(icon, null, tint = color, modifier = Modifier.size(18.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = if (color == OnSurfaceMuted) OnSurfaceMuted else OnSurfacePrimary
            )
        }
    }
}
