package com.example.switchcontrol.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.switchcontrol.ui.theme.*

data class DeviceColorOption(
    val name: String,
    val color: Color,
    val colorKey: String   // el string que se guarda (ej: "orange", "yellow"...)
)

val availableColors = listOf(
    DeviceColorOption("Amarillo",  DeviceYellow,  "yellow"),
    DeviceColorOption("Naranja",   DeviceOrange,  "orange"),
    DeviceColorOption("Verde",     DeviceGreen,   "green"),
    DeviceColorOption("Azul",      DeviceBlue,    "blue"),
    DeviceColorOption("Celeste",   DeviceCyan,    "cyan"),
    DeviceColorOption("Rosa",      DevicePink,    "pink"),
    DeviceColorOption("Violeta",   DevicePurple,  "purple"),
    DeviceColorOption("Rojo",      DeviceRed,     "red"),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ColorPickerBottomSheet(
    currentColorKey: String,
    onColorSelected: (DeviceColorOption) -> Unit,
    onDismiss: () -> Unit,
    sheetState: SheetState = rememberModalBottomSheetState()
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SurfaceCard,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 12.dp)
                    .size(width = 36.dp, height = 4.dp)
                    .clip(CircleShape)
                    .background(SurfaceBorder)
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Text(
                text = "Color del dispositivo",
                style = MaterialTheme.typography.titleLarge,
                color = OnSurfacePrimary,
                fontWeight = FontWeight.Bold
            )

            // Grid de colores — 4 por fila
            val rows = availableColors.chunked(4)
            rows.forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    row.forEach { option ->
                        val isSelected = option.colorKey == currentColorKey
                        Column(
                            modifier = Modifier.weight(1f),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(CircleShape)
                                    .background(option.color)
                                    .border(
                                        width  = if (isSelected) 2.dp else 0.dp,
                                        color  = Color.White,
                                        shape  = CircleShape
                                    )
                                    .clickable { onColorSelected(option); onDismiss() },
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Rounded.Check,
                                        contentDescription = null,
                                        tint = Color.Black.copy(0.7f),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Text(
                                text = option.name,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) option.color else OnSurfaceMuted
                            )
                        }
                    }
                    // Relleno si la fila no es completa
                    repeat(4 - row.size) {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}
