package com.example.switchcontrol.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.switchcontrol.ui.components.*
import com.example.switchcontrol.ui.theme.*

// ─── Modelo de datos de UI ────────────────────────────────────────
// Este modelo es solo para la capa visual. Adaptarlo al modelo existente del proyecto.
data class SwitchUiModel(
    val id: String,
    val name: String,
    val isOn: Boolean,
    val statusText: String,
    val accentColor: Color,
    val icon: ImageVector
)

// Función que mapea el color guardado (String) al Color de UI moderno
fun colorNameToAccent(colorName: String): Color = when (colorName.lowercase()) {
    "yellow"  -> DeviceYellow
    "orange"  -> DeviceOrange
    "green"   -> DeviceGreen
    "blue"    -> DeviceBlue
    "cyan", "lightblue" -> DeviceCyan
    "pink"    -> DevicePink
    "purple", "violet"  -> DevicePurple
    "red"     -> DeviceRed
    else      -> PrimaryBlue
}

// ─── Dashboard ────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    switches: List<SwitchUiModel>,
    onAddSwitch: () -> Unit,
    onSwitchClick: (String) -> Unit,
    onToggle: (String, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val activeCount = switches.count { it.isOn }

    Scaffold(
        modifier = modifier,
        containerColor = BackgroundDark,
        topBar = {
            TopAppBar(
                title = {
                    Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                        Text(
                            text = "Interruptores WiFi",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = OnSurfacePrimary
                        )
                    }
                },
                actions = {
                    // Botón + para agregar
                    FilledIconButton(
                        onClick = onAddSwitch,
                        modifier = Modifier.size(36.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = PrimaryBlue.copy(alpha = 0.15f),
                            contentColor   = PrimaryBlue
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = "Agregar interruptor",
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = BackgroundDark,
                    scrolledContainerColor = SurfaceCard
                )
            )
        }
    ) { innerPadding ->

        if (switches.isEmpty()) {
            EmptyState(
                onAdd = onAddSwitch,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentPadding = PaddingValues(
                    start = 16.dp, end = 16.dp,
                    top = 8.dp, bottom = 32.dp
                ),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Chip de resumen
                item {
                    ActiveSummaryChip(
                        activeCount = activeCount,
                        total = switches.size,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }

                // Cards de dispositivos
                items(
                    items = switches,
                    key = { it.id }
                ) { switch ->
                    DeviceCard(
                        name        = switch.name,
                        accentColor = switch.accentColor,
                        isOn        = switch.isOn,
                        statusText  = switch.statusText,
                        icon        = switch.icon,
                        onCardClick = { onSwitchClick(switch.id) },
                        onToggle    = { isOn -> onToggle(switch.id, isOn) },
                        modifier    = Modifier.animateItem()
                    )
                }
            }
        }
    }
}

// ─── Empty State ─────────────────────────────────────────────────
@Composable
private fun EmptyState(
    onAdd: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(80.dp)
                .background(
                    brush = Brush.radialGradient(
                        listOf(PrimaryBlue.copy(0.15f), Color.Transparent)
                    ),
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.PowerSettingsNew,
                contentDescription = null,
                modifier = Modifier.size(36.dp),
                tint = PrimaryBlue.copy(0.5f)
            )
        }
        Spacer(Modifier.height(20.dp))
        Text(
            text = "Sin interruptores",
            style = MaterialTheme.typography.titleMedium,
            color = OnSurfacePrimary
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = "Agregá tu primer interruptor WiFi",
            style = MaterialTheme.typography.bodyMedium,
            color = OnSurfaceMuted
        )
        Spacer(Modifier.height(24.dp))
        Button(
            onClick = onAdd,
            colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
        ) {
            Icon(Icons.Rounded.Add, null, Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
            Text("Agregar interruptor")
        }
    }
}
