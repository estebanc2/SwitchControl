package com.example.switchcontrol.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.switchcontrol.ui.theme.*

/**
 * Dialog/Sheet para configurar un timer.
 * Reemplaza el diálogo flotante actual con un BottomSheet moderno.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimerBottomSheet(
    accentColor: Color,
    initialStartHour: Int = 0,
    initialStartMin: Int = 0,
    initialEndHour: Int = 0,
    initialEndMin: Int = 1,
    initialDays: Set<Int> = emptySet(),
    onSave: (startH: Int, startM: Int, endH: Int, endM: Int, days: Set<Int>) -> Unit,
    onDiscard: () -> Unit,
    sheetState: SheetState = rememberModalBottomSheetState()
) {
    var startHour by remember { mutableIntStateOf(initialStartHour) }
    var startMin  by remember { mutableIntStateOf(initialStartMin) }
    var endHour   by remember { mutableIntStateOf(initialEndHour) }
    var endMin    by remember { mutableIntStateOf(initialEndMin) }
    var selectedDays by remember { mutableStateOf(initialDays) }

    ModalBottomSheet(
        onDismissRequest = onDiscard,
        sheetState = sheetState,
        containerColor = SurfaceCard,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 12.dp)
                    .size(width = 36.dp, height = 4.dp)
                    .clip(CircleShape)
                    .background(SurfaceBorder)
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // ── Título ──────────────────────────────────────────
            Text(
                text = "Configurar timer",
                style = MaterialTheme.typography.titleLarge,
                color = OnSurfacePrimary,
                fontWeight = FontWeight.Bold
            )

            // ── Horario Inicial ─────────────────────────────────
            TimeSection(
                label      = "HORARIO INICIAL",
                hour       = startHour,
                minute     = startMin,
                accentColor = accentColor,
                onHourChange   = { startHour = it.coerceIn(0, 23) },
                onMinuteChange = { startMin  = it.coerceIn(0, 59) }
            )

            HorizontalDivider(color = SurfaceBorder.copy(0.5f))

            // ── Horario Final ───────────────────────────────────
            TimeSection(
                label      = "HORARIO FINAL",
                hour       = endHour,
                minute     = endMin,
                accentColor = accentColor,
                onHourChange   = { endHour = it.coerceIn(0, 23) },
                onMinuteChange = { endMin  = it.coerceIn(0, 59) }
            )

            HorizontalDivider(color = SurfaceBorder.copy(0.5f))

            // ── Días ─────────────────────────────────────────────
            DaysSelector(
                selectedDays = selectedDays,
                accentColor  = accentColor,
                onDayToggle  = { day ->
                    selectedDays = if (day in selectedDays)
                        selectedDays - day
                    else
                        selectedDays + day
                }
            )

            // ── Botones ──────────────────────────────────────────
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onDiscard,
                    modifier = Modifier.weight(1f),
                    border = BorderStroke(1.dp, SurfaceBorder),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = OnSurfaceMuted)
                ) {
                    Icon(Icons.Rounded.Close, null, Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Descartar")
                }
                Button(
                    onClick = { onSave(startHour, startMin, endHour, endMin, selectedDays) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = accentColor,
                        contentColor = Color.Black.copy(0.85f)
                    )
                ) {
                    Icon(Icons.Rounded.Check, null, Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Guardar", fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

// ─── TimeSection: spinner de hora y minuto ─────────────────────────
@Composable
private fun TimeSection(
    label: String,
    hour: Int,
    minute: Int,
    accentColor: Color,
    onHourChange: (Int) -> Unit,
    onMinuteChange: (Int) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = OnSurfaceMuted,
            letterSpacing = androidx.compose.ui.unit.TextUnit(1.5f, androidx.compose.ui.unit.TextUnitType.Sp)
        )
        Row(
            horizontalArrangement = Arrangement.spacedBy(24.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TimeSpinner(
                label  = "hora",
                value  = hour,
                range  = 0..23,
                accentColor = accentColor,
                onChange = onHourChange
            )
            Text(
                text = ":",
                style = MaterialTheme.typography.headlineMedium,
                color = accentColor,
                fontWeight = FontWeight.Bold
            )
            TimeSpinner(
                label  = "min.",
                value  = minute,
                range  = 0..59,
                accentColor = accentColor,
                onChange = onMinuteChange
            )
        }
    }
}

// ─── TimeSpinner: up/down con valor ──────────────────────────────
@Composable
private fun TimeSpinner(
    label: String,
    value: Int,
    range: IntRange,
    accentColor: Color,
    onChange: (Int) -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = OnSurfaceMuted
        )
        IconButton(
            onClick = { if (value < range.last) onChange(value + 1) },
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(SurfaceElevated)
        ) {
            Icon(Icons.Rounded.KeyboardArrowUp, null, tint = accentColor)
        }
        Text(
            text = "%02d".format(value),
            style = MaterialTheme.typography.headlineMedium,
            color = OnSurfacePrimary,
            fontWeight = FontWeight.Bold
        )
        IconButton(
            onClick = { if (value > range.first) onChange(value - 1) },
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(SurfaceElevated)
        ) {
            Icon(Icons.Rounded.KeyboardArrowDown, null, tint = OnSurfaceMuted)
        }
    }
}

// ─── DaysSelector ─────────────────────────────────────────────────
@Composable
private fun DaysSelector(
    selectedDays: Set<Int>,
    accentColor: Color,
    onDayToggle: (Int) -> Unit
) {
    val days = listOf("Do", "Lu", "Ma", "Mi", "Ju", "Vi", "Sa")

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "DÍAS",
            style = MaterialTheme.typography.labelSmall,
            color = OnSurfaceMuted,
            letterSpacing = androidx.compose.ui.unit.TextUnit(1.5f, androidx.compose.ui.unit.TextUnitType.Sp)
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            days.forEachIndexed { index, day ->
                val selected = index in selectedDays
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(
                            if (selected) accentColor
                            else SurfaceElevated
                        )
                        .border(
                            width = 1.dp,
                            color = if (selected) Color.Transparent else SurfaceBorder,
                            shape = CircleShape
                        )
                        .clickable { onDayToggle(index) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = day,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (selected) Color.Black.copy(0.85f) else OnSurfaceMuted,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
    }
}
