package com.example.switchcontrol.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.switchcontrol.ui.theme.*

/**
 * BottomSheet de mantenimiento del dispositivo.
 * Reemplaza el diálogo actual.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MaintenanceBottomSheet(
    deviceName: String,
    deviceId: String,
    accentColor: Color,
    onFirmwareUpdate: (server: String, port: String) -> Unit,
    onDeleteLocal: () -> Unit,
    onDeleteFactory: () -> Unit,
    onDiscard: () -> Unit,
    sheetState: SheetState = rememberModalBottomSheetState()
) {
    var server by remember { mutableStateOf("") }
    var port   by remember { mutableStateOf("") }
    var showDeleteConfirm by remember { mutableStateOf<DeleteMode?>(null) }
    val clipboard = LocalClipboardManager.current

    if (showDeleteConfirm != null) {
        DeleteConfirmDialog(
            deviceName = deviceName,
            mode = showDeleteConfirm!!,
            onConfirm = {
                when (showDeleteConfirm) {
                    DeleteMode.LOCAL   -> onDeleteLocal()
                    DeleteMode.FACTORY -> onDeleteFactory()
                    null -> {}
                }
            },
            onDismiss = { showDeleteConfirm = null }
        )
    }

    ModalBottomSheet(
        onDismissRequest = onDiscard,
        sheetState = sheetState,
        containerColor = SurfaceCard,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 12.dp)
                    .size(width = 36.dp, height = 4.dp)
                    .clip(CircleShape)
                    .background(SurfaceBorder)
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp)
                .padding(bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Text(
                text = "Mantenimiento",
                style = MaterialTheme.typography.titleLarge,
                color = OnSurfacePrimary,
                fontWeight = FontWeight.Bold
            )

            // ── ID del dispositivo ───────────────────────────────
            SectionLabel("ID PARA CONFIGURAR EN OTRA APP")
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = SurfaceElevated,
                onClick = {
                    clipboard.setText(AnnotatedString(deviceId))
                }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "ID:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = OnSurfaceMuted
                    )
                    Text(
                        text = deviceId,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontFamily = FontFamily.Monospace
                        ),
                        color = accentColor,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(
                        Icons.Rounded.ContentCopy,
                        contentDescription = "Copiar ID",
                        tint = OnSurfaceMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            // ── Actualizar Firmware ──────────────────────────────
            SectionLabel("ACTUALIZAR FIRMWARE")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(SurfaceElevated)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ModernTextField(
                    value = server,
                    onValueChange = { server = it },
                    label = "servidor",
                    placeholder = "192.168.1.100"
                )
                ModernTextField(
                    value = port,
                    onValueChange = { port = it },
                    label = "puerto",
                    placeholder = "8080"
                )
                Button(
                    onClick = { onFirmwareUpdate(server, port) },
                    enabled = server.isNotBlank() && port.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = accentColor,
                        contentColor   = Color.Black.copy(0.85f)
                    )
                ) {
                    Icon(Icons.Rounded.Upload, null, Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Actualizar", fontWeight = FontWeight.SemiBold)
                }
            }

            // ── Eliminar interruptor ──────────────────────────────
            SectionLabel("ELIMINAR INTERRUPTOR")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(SurfaceElevated),
                verticalArrangement = Arrangement.spacedBy(1.dp)
            ) {
                DeleteRow(
                    icon  = Icons.Rounded.PhonelinkErase,
                    text  = "Eliminar $deviceName en esta aplicación",
                    color = DeviceOrange,
                    onClick = { showDeleteConfirm = DeleteMode.LOCAL }
                )
                HorizontalDivider(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    color = SurfaceBorder.copy(0.4f)
                )
                DeleteRow(
                    icon  = Icons.Rounded.DeleteForever,
                    text  = "Eliminar $deviceName y dejar el interruptor desconfigurado (de fábrica)",
                    color = DeviceRed,
                    onClick = { showDeleteConfirm = DeleteMode.FACTORY }
                )
            }

            // ── Botón cerrar ─────────────────────────────────────
            OutlinedButton(
                onClick = onDiscard,
                modifier = Modifier.fillMaxWidth(),
                border = BorderStroke(1.dp, SurfaceBorder),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = OnSurfaceMuted)
            ) {
                Icon(Icons.Rounded.Close, null, Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Cerrar")
            }
        }
    }
}

enum class DeleteMode { LOCAL, FACTORY }

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelSmall,
        color = OnSurfaceMuted,
        letterSpacing = androidx.compose.ui.unit.TextUnit(1.5f, androidx.compose.ui.unit.TextUnitType.Sp)
    )
}

@Composable
private fun ModernTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String = ""
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        label = {
            Text(label, style = MaterialTheme.typography.bodySmall, color = OnSurfaceMuted)
        },
        placeholder = {
            Text(placeholder, style = MaterialTheme.typography.bodyMedium, color = OnSurfaceMuted.copy(0.4f))
        },
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor   = PrimaryBlue,
            unfocusedBorderColor = SurfaceBorder,
            focusedTextColor     = OnSurfacePrimary,
            unfocusedTextColor   = OnSurfacePrimary,
            cursorColor          = PrimaryBlue,
            focusedLabelColor    = PrimaryBlue,
            unfocusedLabelColor  = OnSurfaceMuted
        ),
        shape = RoundedCornerShape(10.dp),
        singleLine = true
    )
}

@Composable
private fun DeleteRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String,
    color: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = Color.Transparent
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium,
                color = color
            )
        }
    }
}

@Composable
private fun DeleteConfirmDialog(
    deviceName: String,
    mode: DeleteMode,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor   = SurfaceCard,
        title = {
            Text(
                text = if (mode == DeleteMode.LOCAL) "Eliminar de la app" else "Restablecer de fábrica",
                color = OnSurfacePrimary,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Text(
                text = if (mode == DeleteMode.LOCAL)
                    "¿Eliminar $deviceName de esta aplicación? El interruptor seguirá configurado en la red."
                else
                    "¿Eliminar $deviceName y restaurar la configuración de fábrica del dispositivo? Esta acción no se puede deshacer.",
                color = OnSurfaceMuted,
                style = MaterialTheme.typography.bodyMedium
            )
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(); onDismiss() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = DeviceRed,
                    contentColor = Color.White
                )
            ) { Text("Eliminar", fontWeight = FontWeight.SemiBold) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = OnSurfaceMuted)
            }
        }
    )
}
