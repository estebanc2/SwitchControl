package com.example.switchcontrol.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.switchcontrol.ui.theme.*

/**
 * Card principal de cada interruptor en el dashboard.
 *
 * @param name          Nombre del dispositivo (ej: "Luz cocina")
 * @param accentColor   Color del dispositivo (ej: DeviceYellow, DeviceOrange, etc.)
 * @param isOn          Estado actual del switch
 * @param statusText    Texto de estado (ej: "Cambia en 12:51 h", "Enciende si temp < 20°")
 * @param icon          Ícono representativo del dispositivo
 * @param onCardClick   Se llama al tocar la card (para ir al detalle)
 * @param onToggle      Se llama al tocar el switch
 */
@Composable
fun DeviceCard(
    name: String,
    accentColor: Color,
    isOn: Boolean,
    statusText: String,
    icon: ImageVector = Icons.Rounded.PowerSettingsNew,
    onCardClick: () -> Unit = {},
    onToggle: (Boolean) -> Unit = {},
    modifier: Modifier = Modifier
) {
    // Animaciones al cambiar estado
    val glowAlpha by animateFloatAsState(
        targetValue = if (isOn) 0.25f else 0f,
        animationSpec = tween(400, easing = EaseInOutCubic),
        label = "glow"
    )
    val cardAlpha by animateFloatAsState(
        targetValue = if (isOn) 1f else 0.6f,
        animationSpec = tween(300),
        label = "cardAlpha"
    )
    val iconScale by animateFloatAsState(
        targetValue = if (isOn) 1f else 0.85f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "iconScale"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            // Glow effect detrás de la card cuando está ON
            .drawBehind {
                if (glowAlpha > 0f) {
                    drawCircle(
                        color = accentColor.copy(alpha = glowAlpha * 0.4f),
                        radius = size.width * 0.6f,
                        center = Offset(size.width * 0.15f, size.height * 0.5f),
                    )
                }
            }
    ) {
        Card(
            onClick = onCardClick,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = SurfaceCard
            ),
            border = BorderStroke(
                width = 1.dp,
                brush = if (isOn)
                    Brush.horizontalGradient(
                        listOf(accentColor.copy(alpha = 0.5f), SurfaceBorder.copy(alpha = 0.3f))
                    )
                else
                    Brush.horizontalGradient(
                        listOf(SurfaceBorder.copy(alpha = 0.4f), SurfaceBorder.copy(alpha = 0.2f))
                    )
            ),
            elevation = CardDefaults.cardElevation(
                defaultElevation = if (isOn) 0.dp else 0.dp
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Ícono con fondo de color
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            if (isOn) accentColor.copy(alpha = 0.18f)
                            else Color.White.copy(alpha = 0.05f)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (isOn) accentColor else OnSurfaceMuted,
                        modifier = Modifier
                            .size(24.dp)
                            .graphicsLayer(
                                scaleX = iconScale,
                                scaleY = iconScale
                            )
                    )
                }

                // Nombre + estado
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text(
                        text = name,
                        style = MaterialTheme.typography.titleMedium,
                        color = if (isOn) OnSurfacePrimary else OnSurfacePrimary.copy(alpha = 0.7f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = statusText,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (isOn) accentColor.copy(alpha = 0.8f) else OnSurfaceMuted,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Switch moderno
                ModernSwitch(
                    checked = isOn,
                    onCheckedChange = onToggle,
                    color = accentColor
                )
            }
        }
    }
}

/**
 * Switch personalizado con animación suave y color del dispositivo.
 */
@Composable
fun ModernSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    color: Color,
    modifier: Modifier = Modifier
) {
    Switch(
        checked = checked,
        onCheckedChange = onCheckedChange,
        modifier = modifier,
        colors = SwitchDefaults.colors(
            checkedThumbColor      = Color.White,
            checkedTrackColor      = color,
            checkedBorderColor     = color,
            checkedIconColor       = color,
            uncheckedThumbColor    = OnSurfaceMuted,
            uncheckedTrackColor    = SurfaceElevated,
            uncheckedBorderColor   = SurfaceBorder,
        ),
        thumbContent = {
            AnimatedContent(
                targetState = checked,
                transitionSpec = { scaleIn() togetherWith scaleOut() },
                label = "thumbIcon"
            ) { isChecked ->
                if (isChecked) {
                    Icon(
                        imageVector = Icons.Rounded.Check,
                        contentDescription = null,
                        modifier = Modifier.size(12.dp),
                        tint = color
                    )
                }
            }
        }
    )
}

/**
 * Chip de resumen: "N activos de M"
 */
@Composable
fun ActiveSummaryChip(
    activeCount: Int,
    total: Int,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = if (activeCount > 0)
            PrimaryBlue.copy(alpha = 0.12f)
        else
            SurfaceElevated
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(
                        color = if (activeCount > 0) PrimaryBlue else OnSurfaceMuted,
                        shape = CircleShape
                    )
            )
            Text(
                text = if (activeCount > 0)
                    "$activeCount activo${if (activeCount > 1) "s" else ""} de $total"
                else
                    "Todos apagados",
                style = MaterialTheme.typography.labelLarge,
                color = if (activeCount > 0) PrimaryBlue else OnSurfaceMuted
            )
        }
    }
}
