package com.example.switchcontrol.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// ─── Paleta Principal ────────────────────────────────────────────
val PrimaryBlue      = Color(0xFF60A5FA)   // blue-400
val PrimaryBlueDim   = Color(0xFF1D4ED8)   // blue-700
val SurfaceCard      = Color(0xFF111827)   // gray-900
val SurfaceElevated  = Color(0xFF1F2937)   // gray-800
val SurfaceBorder    = Color(0xFF374151)   // gray-700
val OnSurfacePrimary = Color(0xFFF9FAFB)   // gray-50
val OnSurfaceMuted   = Color(0xFF9CA3AF)   // gray-400
val BackgroundDark   = Color(0xFF030712)   // gray-950

// Colores por tipo de dispositivo (coinciden con los colores actuales pero modernizados)
val DeviceYellow     = Color(0xFFFBBF24)   // amber-400
val DeviceOrange     = Color(0xFFF97316)   // orange-500
val DeviceGreen      = Color(0xFF34D399)   // emerald-400
val DeviceBlue       = Color(0xFF818CF8)   // indigo-400
val DeviceCyan       = Color(0xFF22D3EE)   // cyan-400
val DevicePink       = Color(0xFFF472B6)   // pink-400
val DevicePurple     = Color(0xFFA78BFA)   // violet-400
val DeviceRed        = Color(0xFFF87171)   // red-400

private val DarkColorScheme = darkColorScheme(
    primary          = PrimaryBlue,
    onPrimary        = Color(0xFF1E3A5F),
    primaryContainer = Color(0xFF1D3461),
    onPrimaryContainer = Color(0xFFBFDBFE),
    secondary        = Color(0xFF94A3B8),
    onSecondary      = Color(0xFF1E293B),
    background       = BackgroundDark,
    onBackground     = OnSurfacePrimary,
    surface          = SurfaceCard,
    onSurface        = OnSurfacePrimary,
    surfaceVariant   = SurfaceElevated,
    onSurfaceVariant = OnSurfaceMuted,
    outline          = SurfaceBorder,
    error            = Color(0xFFF87171),
    onError          = Color(0xFF450A0A),
)

@Composable
fun SwitchControlTheme(
    darkTheme: Boolean = true, // dark por defecto — es una app de control, dark es mejor
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        else -> DarkColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = BackgroundDark.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography  = AppTypography,
        content     = content
    )
}
